from setuptools import setup

setup(
    name='macarer',
    version='1.0.0',
    description='The script created to optimize the battery charging state of the MacBook.',
    author='Kato Shinya',
    author_email='kato.shinya.dev@gmail.com',
    url='https://github.com/myConsciousness/macarer',
)
